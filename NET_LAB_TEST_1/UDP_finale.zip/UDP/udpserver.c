/* 
 * udpserver.c - A UDP echo server 
 * usage: udpserver <port_for_server>
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <sys/time.h>
#include <arpa/inet.h> 
#include <fcntl.h>
#include <stdbool.h>


#define COLOR_RED     "\x1b[31m"
#define COLOR_GREEN   "\x1b[32m"
#define COLOR_YELLOW  "\x1b[33m"
#define COLOR_BLUE    "\x1b[34m"
#define COLOR_MAGENTA "\x1b[35m"
#define COLOR_CYAN    "\x1b[36m"
#define COLOR_RESET   "\x1b[0m"

#define TIMEOUT_MS      100

#define BUFSIZE 1024
char OK[1]="1";
char ERROR[1]="0";

struct timeval timeout={60,0}; //set timeout for 60 seconds

char *END_FLAG = "================END";
/*
 * error - wrapper for perror
 */
void error(char *msg) {
 
  perror(msg);
  
  exit(1);
}


typedef struct buffer
{
  int sequence_no;
  int chunk_size;
  char data[BUFSIZE+1];
}buffer;

char* getfName(char* buf){
  int l=strlen(buf);
  int count=0;
  for (int i = 0; i < l; ++i)
  {
    if(buf[i]=='/')count++;
  }
  if(count<1)return buf;
  strtok(buf,"/");
  if(count<2)return strtok(NULL,"/");;

  for (int i = 0; i < count-2; ++i)
  {
    strtok(NULL,"/");
  }
  return strtok(NULL,"/");
}
bool checkFile( char *buf)
{
    strcpy(buf,strtok(buf,"\n"));
    // strtok(buf,"/");
    strcpy(buf,getfName(buf));
    char folder[15]="Received_data/";
    strcat(folder,buf);
    strcpy(buf,folder);

    // printf("%s\n",buf);
    FILE *fp;
    fp=fopen(buf,"r");
    
    // long int fsize=0;
    char text;
    // char *data=(char*)malloc(MAX_FILE_SIZE*si`zeof(char));
    if(fp){
      printf(COLOR_RED  "ERROR file already exist.\n"COLOR_RESET);
      return true;
    }
    return false;
    // while((fscanf(fp,"%c",&text)==1))fsize++;
    // return fsize;
}
 

int main(int argc, char **argv) {
  int sockfd; /* socket file descriptor - an ID to uniquely identify a socket by the application program */
  int portno; /* port to listen on */
  int clientlen; /* byte size of client's address */
  struct sockaddr_in serveraddr; /* server's addr */
  struct sockaddr_in clientaddr; /* client addr */
  struct hostent *hostp; /* client host info */
  char buf[BUFSIZE]; /* message buf */
  char *hostaddrp; /* dotted decimal host addr string */
  int optval; /* flag value for setsockopt */
  int n; /* message byte size */

  /* 
   * check command line arguments 
   */
  if (argc != 2) {
    fprintf(stderr, "usage: %s <port_for_server>\n", argv[0]);
    exit(1);
  }
  portno = atoi(argv[1]);

  /* 
   * socket: create the socket 
   */
  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0) 
    error("ERROR opening socket");

  /* setsockopt: Handy debugging trick that lets 
   * us rerun the server immediately after we kill it; 
   * otherwise we have to wait about 20 secs. 
   * Eliminates "ERROR on binding: Address already in use" error. 
   */
  optval = 1;
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,(const void *)&optval , sizeof(int));

  /*
   * build the server's Internet address
   */
  bzero((char *) &serveraddr, sizeof(serveraddr));
  serveraddr.sin_family = AF_INET;
  serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
  serveraddr.sin_port = htons((unsigned short)portno);

  /* 
   * bind: associate the parent socket with a port 
   */
  if (bind(sockfd, (struct sockaddr *) &serveraddr,sizeof(serveraddr)) < 0) 
    error("ERROR on binding");

  /* 
   * main loop: wait for a datagram, then echo it
   */
  clientlen = sizeof(clientaddr);

  while (1) {
    printf(COLOR_CYAN "UDP Server is running.........\n"COLOR_RESET);
    /*
     * recvfrom: receive a UDP datagram from a client
     */
    char testing[BUFSIZE];
    bzero(buf, BUFSIZE);
    n = recvfrom(sockfd, testing, BUFSIZE, 0,(struct sockaddr *) &clientaddr, &clientlen);
    if (n < 0)error("ERROR in recvfrom");

    /* 
     * gethostbyaddr: determine who sent the datagram
     */
    /*hostp = gethostbyaddr((const char *)&clientaddr.sin_addr.s_addr,sizeof(clientaddr.sin_addr.s_addr), AF_INET);
    if (hostp == NULL)error("ERROR on gethostbyaddr");
    hostaddrp = inet_ntoa(clientaddr.sin_addr);
    if (hostaddrp == NULL)error("ERROR on inet_ntoa\n");*/
    // printf("server received connection request from %s (%s)\n",hostp->h_name, hostaddrp);
    printf("server received connection request from ");
    printf(COLOR_CYAN "%d.%d.%d.%d\n"COLOR_RESET,(int)(clientaddr.sin_addr.s_addr&0xFF),(int)((clientaddr.sin_addr.s_addr&0xFF00)>>8),
                  (int)((clientaddr.sin_addr.s_addr&0xFF0000)>>16),(int)((clientaddr.sin_addr.s_addr&0xFF000000)>>24));
    n = sendto(sockfd, "ok", strlen("ok"), 0,(struct sockaddr *) &clientaddr, clientlen);
    if (n < 0) error("ERROR in sendto");

    /* 
     * receive file details echo the input back to the client 
     */
   
    n = recvfrom(sockfd, buf, BUFSIZE, 0,(struct sockaddr *) &clientaddr, &clientlen);
    if (n < 0)error("ERROR in recvfrom");
    int x=strlen(buf);
    printf("server received %d/%d bytes: %s\n", x, n, buf);
    if(atoi(&buf[0])){
      printf(COLOR_RED "ERROR :  No filename received...\n" COLOR_RESET);
      continue;
    }
    /*
    file existance..
    */
    bool existance= checkFile(buf);
    // if(existance)printf("sachin \n");;
    /*
    send existace info
    */
    char message[1]="0";
    if(existance)strcpy(message,"1");
    n = sendto(sockfd, message, strlen(message), 0,(struct sockaddr *) &clientaddr, clientlen);
    
    if (n < 0) error("ERROR in sendto");
    if(existance)continue;
      
    
    /*
    getting file size and number of chunks
    */

    char s_fsize[BUFSIZE],s_no_chunks[BUFSIZE];

    n = recvfrom(sockfd,s_fsize, BUFSIZE, 0,(struct sockaddr *) &clientaddr, &clientlen);
    if (n < 0)error("ERROR in recvfrom");

    n = recvfrom(sockfd,s_no_chunks, BUFSIZE, 0,(struct sockaddr *) &clientaddr, &clientlen);
    if (n < 0)error("ERROR in recvfrom");

    // printf("%s,%s\n",s_fsize,s_no_chunks );
    int fsize=atoi(s_fsize),no_chunks=atoi(s_no_chunks);
    printf("file size:%d, number of chunks:%d\n",fsize,no_chunks );

    n = sendto(sockfd, "ok", strlen("ok"), 0,(struct sockaddr *) &clientaddr, clientlen);
    if (n < 0) error("ERROR in sendto");



    char fileName[BUFSIZE];
    char fContent[BUFSIZE+50];
    strcpy(buf,strtok(buf, "\n"));
    strcpy(fileName,buf);//saving filename for future use
    int fd = open(buf, O_RDWR | O_CREAT, 0777);
    int chunk_no=0,size=0;
    /*


    Receiving chunks.............
    
    */
    int prev_sequence_no=0,sequence_no=-1,prev_chunk_size=-1,chunk_size=-1;
    char *sqn_no;
    char * chnkS;
    char Header[BUFSIZE];
    strcpy(message,"0");
    
    int send[1]={0};
    buffer *received_data=(buffer *)malloc(1*sizeof(buffer));
    received_data->sequence_no=0;
    received_data->chunk_size=0;
    while ((n = recvfrom(sockfd,received_data,  2*BUFSIZE, 0, (struct sockaddr *) &clientaddr, &clientlen))>0) {
        strcpy(fContent,received_data->data);
        // fContent[n]=0;
        if (!(strcmp(fContent, END_FLAG))) break;
        size=size+n;
        chunk_no++;
        if((chunk_no%200)==0||chunk_no==no_chunks-1)
        printf("Receiving %dth chunk of size:%d bytes....................%d bytes received\n",chunk_no,n,size );
        fContent[n] = 0;
       
        

        sequence_no=received_data->sequence_no; //strtok(Header,"\n");
        chunk_size=received_data->chunk_size; //strtok(NULL,"\n");
        if(prev_sequence_no==sequence_no)send[0]=1;
        else send[0]=0;
        if(sendto(sockfd, send, 1, 0,(struct sockaddr *) &clientaddr, clientlen)<0)
          error("ERROR");

        if(prev_sequence_no!=sequence_no&&(prev_sequence_no+1)==sequence_no)
           {  
             int q;
            if((q=write(fd, received_data->data,received_data->chunk_size))<0)
                  perror(COLOR_RED"ERROR ");
              }
        prev_sequence_no=sequence_no;
        prev_chunk_size=chunk_size;
        bzero(received_data->data,BUFSIZE);
        bzero(fContent,BUFSIZE);


    }
    // printf("filename:%s\n",buf );
    printf("%f Mb\n",(float)((float)fsize/(1024.0*1024.0)) );
    close(fd);


    /*
     *
    Creating md5sum 
    *
    */


    // printf("filename:%s\n",fileName );
    char md5checksum[BUFSIZE]="md5sum ";
    strcat(md5checksum,fileName);
    strcat(md5checksum," > 7879797");
    unsigned int md5;
    md5 = system(md5checksum);
    char MD5[1000];
    char text;
    int i=0;
    FILE *md=fopen("7879797","r");
    while((fscanf(md,"%c",&text))==1)MD5[i++]=text;
    fclose(md);
    
    remove("7879797");
    n = sendto(sockfd, MD5, strlen(MD5), 0,(struct sockaddr *) &clientaddr, clientlen);
    // printf("%s\n",MD5 );
   
  }
}
