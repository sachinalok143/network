/* 
 * udpclient.c - A simple UDP client
 * usage: udpclient <host> <port>
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <sys/stat.h>
#include <arpa/inet.h> 
#include <fcntl.h>
#include <sys/time.h>

#define BUFSIZE 1024


#define TIMEOUT_MS      100

/* 
 * error - wrapper for perror
 */
#define COLOR_RED     "\x1b[31m"
#define COLOR_GREEN   "\x1b[32m"
#define COLOR_YELLOW  "\x1b[33m"
#define COLOR_BLUE    "\x1b[34m"
#define COLOR_MAGENTA "\x1b[35m"
#define COLOR_CYAN    "\x1b[36m"
#define COLOR_RESET   "\x1b[0m"
void error(char *msg) {
  perror(msg);
  exit(1);
}
struct timeval timeout={1,0};

typedef struct buffer
{
  int sequence_no;
  int chunk_size;
  char data[BUFSIZE+1];
}buffer;

long int findSize( char *buf)
{
    strcpy(buf,strtok(buf,"\n"));
    // printf("%s\n",buf);
    FILE *fp;
    fp=fopen(buf,"r" );
    
    long int fsize=0;
    char text;
    // char *data=(char*)malloc(MAX_FILE_SIZE*si`zeof(char));
    if(fp==NULL)return -1;
    
    while((fscanf(fp,"%c",&text)==1))fsize++;
    return fsize;
}
 

char* itoa(int val, int base){
    
    static char buf[32] = {0};
    
    int i = 30;
    
    for(; val && i ; --i, val /= base)
    
        buf[i] = "0123456789abcdef"[val % base];
    
    return &buf[i+1];
    
}

int main(int argc, char **argv) {
    int sockfd, portno, n;
    int serverlen;
    struct sockaddr_in serveraddr;
    struct hostent *server;
    char *hostname;
    char buf[BUFSIZE];



    struct sockaddr_in servaddr;
  

    /* check command line arguments */
    if (argc != 3) {
       fprintf(stderr,"usage: %s <hostname> <port>\n", argv[0]);
       exit(0);
    }
    hostname = argv[1];
    portno = atoi(argv[2]);

     bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(portno);
    inet_pton(AF_INET, argv[1], &servaddr.sin_addr);


    /* socket: create the socket */
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) 
        error(COLOR_RED "ERROR opening socket" COLOR_RESET);

    /* gethostbyname: get the server's DNS entry */
    server = gethostbyname(hostname);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host as %s\n", hostname);
        exit(0);
    }

    /* build the server's Internet address */
    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serveraddr.sin_addr.s_addr, server->h_length);
    serveraddr.sin_port = htons(portno);

    serverlen = sizeof(serveraddr);
    /*
    testing connetion
    */
    n = sendto(sockfd, "testing...", strlen("testing..." ), 0, (struct sockaddr *) &serveraddr, serverlen);
    if (n < 0) 
      error(COLOR_RED "ERROR in sendto" COLOR_RESET);
    else{
        printf("connecting to...........");printf(COLOR_GREEN "\t%s:%d\n"COLOR_RESET,hostname,portno );
    }
    char response[2];

   
      setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char*)&timeout,sizeof(struct timeval));
     n = recvfrom(sockfd, response, strlen(response), 0,(struct sockaddr *) &serveraddr, &serverlen);
    if (n < 0) 
      error(COLOR_RED "ERROR in recvfrom" COLOR_RESET);
    else
        printf("Connection esteblished......\n" );

    /* get a message from the user */
    bzero(buf, BUFSIZE);
    printf("Please enter file name: ");
    fgets(buf, BUFSIZE, stdin);
    long int fsize=findSize(buf);
    /* send the message to the server */
    if(fsize<0){
        n = sendto(sockfd, "1", strlen("1"), 0, (struct sockaddr *) &serveraddr, serverlen);
        if (n < 0) 
        error(COLOR_RED "ERROR in sendto" COLOR_RESET);
        
        error(COLOR_RED "ERROR file doesn't exist." COLOR_RESET);
    }
    strcpy(buf,strtok(buf,"\n" ));
    n = sendto(sockfd, buf, strlen(buf), 0, (struct sockaddr *) &serveraddr, serverlen);
    if (n < 0) 
      error(COLOR_RED "ERROR in sendto" COLOR_RESET);
    


  /*
  get responce about existance of file.
  */
  char *existance=(char*)malloc(BUFSIZE*sizeof(char));
  strcpy(existance,"1" );
        // printf("%s,%d\n", existance,strlen(existance));

  // bzero(existance,BUFSIZE);
      setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char*)&timeout,sizeof(struct timeval));
     n = recvfrom(sockfd, existance, strlen(existance), 0,(struct sockaddr *) &serveraddr, &serverlen);
    if (n < 0)error(COLOR_RED "ERROR in recvfrom" COLOR_RESET);
    else
    {
        // printf("%s\n", existance);
        if(atoi(existance))error(COLOR_RED "File already exist on serve" COLOR_RESET);
    }


  /*
    send file size and no of chunks
  */

    n = sendto(sockfd, itoa(fsize,10), strlen(itoa(fsize,10)), 0, (struct sockaddr *) &serveraddr, serverlen);
    if (n < 0) 
      error(COLOR_RED "ERROR in sendto" COLOR_RESET);
    // printf("%ld\n",fsize );

    n = sendto(sockfd, itoa(((fsize/1024)+1),10), strlen(itoa(((fsize/1024)+1),10)), 0, (struct sockaddr *) &serveraddr, serverlen);
    if (n < 0) 
      error(COLOR_RED "ERROR in sendto" COLOR_RESET);

    printf("file size:%ld bytes, number of chunks:%ld\n",fsize,((fsize/1024)+1) );    



    /* print the server's reply */
     setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(char*)&timeout,sizeof(struct timeval));
    n = recvfrom(sockfd, response, strlen(response), 0,(struct sockaddr *) &serveraddr, &serverlen);
    if (n < 0) 
      error(COLOR_RED "ERROR in recvfrom" COLOR_RESET);
  	

    if (!strncmp(response, "ok", 2)) {
        printf("Filename sent.\n" );
    }


    char *END_FLAG = "================END";

    char * fContent=(char*)malloc((BUFSIZE+50)*sizeof(char));
    int fd;
    strcpy(buf,strtok(buf, "\n" ));
    fd = open(buf, O_RDONLY);
    
    if(fd<0)error(COLOR_RED "ERROR,file doesn't exist:" COLOR_RESET);
    
  
    int sequnce_no=1,chunk_size=0;
    int chunk_no=0,size=0;
    int Received[1]={0};
   
    buffer *data_to_send=(buffer *)malloc(1*sizeof(buffer));
    while ((n = read(fd,  data_to_send->data, BUFSIZE)) >0) {
         chunk_size=strlen(data_to_send->data);
    	size=size+chunk_size;
    	chunk_no++;
        /*
        
        creating header

        */
         data_to_send->sequence_no=sequnce_no;
         data_to_send->chunk_size=n;
         do{
                if((chunk_no%200)==0||chunk_no==(fsize/1024))
                printf("Sending %d th chunk of size:%dbytes.....................%f Mb received\n",
                  chunk_no,chunk_size,(float)size/(1024.0*1024));
                sendto(sockfd, data_to_send, 2*BUFSIZE, 0, (struct sockaddr *) &servaddr, sizeof(servaddr));
                if(recvfrom(sockfd, Received, 1, 0,(struct sockaddr *) &serveraddr, &serverlen) < 0) 
                    error(COLOR_RED "ERROR in recvfrom" COLOR_RESET);
                // sleep(1);
            }
            while(Received[0]);
   		sequnce_no++;
        bzero(data_to_send->data,BUFSIZE);
        bzero(fContent,BUFSIZE);

    }
     strcpy(data_to_send->data,END_FLAG);
         data_to_send->sequence_no=sequnce_no++;
         data_to_send->chunk_size=sizeof(END_FLAG);
    printf("%f Mb\n",(float)((float)fsize/(1024*1024)));
    sendto(sockfd, data_to_send, BUFSIZE, 0, (struct sockaddr *) &servaddr, sizeof(servaddr));
    



    /*
    Receive md5 of file which is just sent and 
    macthing them to the md5 of client file
    */

    char md5[1000];
    char text;
    bzero(md5, BUFSIZE);
    // printf("sachin\n" );
    n = read(sockfd, md5, BUFSIZE);
    if (n < 0) 
      error(COLOR_RED "ERROR reading from socket" COLOR_RESET);
    
    n=strlen(md5);
    char *name=(char*)malloc(n*sizeof(char));
    name = strtok(NULL, " ");
    name = strtok(md5, " ");
    
    char md5checksum[BUFSIZE]="md5sum ";
    strcat(md5checksum,buf);
    strcat(md5checksum," > 7879797" );
    // printf("%s\n",md5 );
    system(md5checksum);
    char MD5[1000];
    // char text;
    int i=0;
    FILE *md=fopen("7879797","r" );
    while((fscanf(md,"%c",&text))==1)MD5[i++]=text;
    fclose(md);
    n=strlen(MD5);
    char *name1=(char*)malloc(n*sizeof(char));
    name1 = strtok(NULL, " " );
    name1 = strtok(MD5, " " );
    printf("%s\n",md5 );
    printf("%s\n",MD5 );
    remove("7879797" );
    if(strcmp(md5,MD5))printf(COLOR_MAGENTA "MD5 Not Matched..........\n" COLOR_RESET );
    else printf(COLOR_GREEN "MD5 Matched............\n"COLOR_RESET );
    // printf("%d\n", );
    close(sockfd);





    return 0;
}
